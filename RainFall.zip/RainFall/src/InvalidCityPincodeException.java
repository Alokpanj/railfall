
public class InvalidCityPincodeException {

}
